function g = ncgr_graphic()
% For plotting purposes

    g.h = -1;
    g.quiver_x = -1;
    g.quiver_y = -1;
    g.quiver_z = -1;

end